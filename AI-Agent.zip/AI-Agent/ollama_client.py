"""
Shared, resilient wrapper around ollama.chat() for vision calls.

Wraps every call with the process-wide concurrency limit (ollama_concurrency.py)
and a single CPU-only retry when the GPU backend fails in a way consistent
with the known Vulkan-on-Intel-iGPU instability (see ollama/ollama#13086,
#13964, #5387, #18477). Confirmed on this machine to show up as at least two
distinct symptoms of the same underlying backend problem:
  - "token repeat limit reached" — Ollama's own safety abort on degenerate
    repeating output (a soft failure — the runner survives).
  - "ErrorDeviceLost" (vk::Queue::submit) — a hard Vulkan device crash that
    kills and core-dumps the whole llama-server runner subprocess.
Neither is a hard capability limit of the model itself — CPU inference is
much slower but numerically stable, so retrying once on CPU trades latency
for correctness/availability on whichever documents trigger either failure,
instead of silently giving up.
"""

import ollama

from ollama_concurrency import ollama_semaphore

GPU_BACKEND_FAILURE_MARKERS = (
    "token repeat limit reached",
    "ErrorDeviceLost",
    "device lost",
    "model runner has unexpectedly stopped",
)


def _is_gpu_backend_failure(exc: Exception) -> bool:
    text = str(exc)
    return any(marker.lower() in text.lower() for marker in GPU_BACKEND_FAILURE_MARKERS)


def vision_chat(model: str, messages: list, retry_on_cpu: bool = True) -> dict:
    with ollama_semaphore:
        try:
            return ollama.chat(model=model, messages=messages)
        except Exception as e:
            if not retry_on_cpu or not _is_gpu_backend_failure(e):
                raise
            print(
                f"  ⚠️  {model}: GPU/Vulkan backend failure ({e}) — retrying on CPU "
                "(num_gpu=0, slower but numerically stable)..."
            )
            return ollama.chat(model=model, messages=messages, options={"num_gpu": 0})
