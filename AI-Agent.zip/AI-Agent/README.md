# ID Document Extraction API v5.0

Multi-channel identity document extraction — architecture ported from
[ID-Document-Extractor](/home/mesay/Desktop/ID-Document-Extractor), with
Gemini replaced by local Ollama vision models throughout. Built for:
**HP ZBook Firefly 15 G8 | 32GB RAM | Intel Iris Xe GPU (22.8GB VRAM)**

---

## Architecture: 5 channels, most-trustworthy first

A photo goes through a waterfall, not a single model call. Each channel
only runs if the ones before it didn't produce enough, and a higher
channel's field is **never overwritten** by a lower one — disagreement
sets `human_review_required` instead of silently picking a value.

```
1. Barcode / QR    PDF417 (AAMVA US/CA driver's licenses & ID cards),
                   Ethiopian Digital ID FAN (Code128) + QR
                   → CRC/Reed-Solomon verified — fully trusted on decode

2. MRZ             ICAO 9303 TD1 (national ID) / TD2 / TD3 (passport)
                   → real check-digit validation

3. AI-vision       Ollama qwen2.5vl:7b, single-shot — enriches gaps a
   crosscheck      verified source left (place of birth, issuing
                   authority, ...), never overwrites what's verified

4. AI-vision       Ollama's 4-stage sequential pipeline (moondream →
   universal        qwen2.5vl:7b → llava:13b → qwen2.5vl:7b, each stage
   fallback         sees and corrects the previous one) — full read when
                   nothing structural matched at all

5. Generic OCR     Label-alias regex sweep, multi-language ontology —
   floor            the floor. Always runs if nothing else did; never
                   returns an empty profile.
```

See `idx/pipeline.py` for the orchestrator and `CLAUDE.md`/`docs/` in
the source project for the full design philosophy this inherits.

## Local OCR engine

`idx/ocr_engine.py`: **RapidOCR** (ONNX, CPU-only) primary, tesseract
fallback/vote. Deliberately CPU-only — it never competes with Ollama for
the Iris Xe GPU, which matters a lot on this machine (see "Known issues"
below). Most documents with a barcode or MRZ resolve via channels 1-2
without ever touching Ollama or the GPU at all.

## Ollama models (channels 3-4 only)

```
qwen2.5vl:7b      6.0GB   Field extractor + layout analyzer (multilingual)
                          Also the single-shot model for crosscheck calls
llava:13b         8.0GB   Accuracy verifier
moondream:latest  1.7GB   Fast pre-scanner
```

## Multi-country / multi-language coverage

- `idx/countries.py` + `idx/ontology/icao_prado_entities.yaml` — ISO 3166-1 / ICAO PRADO issuing-state and nationality codes.
- `idx/ontology.py` + `idx/concepts/` — per-field label aliases in 9 languages (`am`, `ar`, `de`, `en`, `es`, `fr`, `it`, `ja`, `zh`), fuzzy-matched with a same-field-only guard.
- `idx/ontology/aamva_jurisdictions.yaml` — per-US-state/Canada-province facts as data, never `if state == "..."` branches in Python.
- `idx/ethiopia_id.py` — dedicated module for the Ethiopian Digital ID ("Fayda") card, both generations (FAN and FCN), dual-calendar (Ethiopian/Gregorian) date handling.

**Known, honest gap**: AAMVA's front-only OCR fallback (reading a driver's
license visually when its barcode doesn't decode) is not implemented —
the source project's version was tuned against specific real card photos
that don't exist here; see `idx/aamva.py`'s module docstring. A driver's
license with an undecodable barcode falls through to the generic OCR/AI
tiers instead of a bespoke reader.

---

## Setup

```bash
# Create/activate the conda env (Python 3.12) and install dependencies
conda create -n myenv python=3.12   # first time only
conda activate myenv
pip install -r requirements.txt

# tesseract binary must be installed system-wide too (OCR fallback):
#   conda (any OS, no sudo): conda install -n myenv -c conda-forge tesseract
#   macOS with Homebrew:     brew install tesseract
#   Ubuntu:                  sudo apt install tesseract-ocr

# Verify Ollama models are installed
ollama list

# Start API
python main.py
# or: uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

---

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/` | Service info, architecture, supported document types/languages |
| GET | `/health` | Ollama model status + local OCR engine + GPU info |
| GET | `/agents` | The 5 channels, in precedence order, with what each covers |
| POST | `/extract/id?doc_type=auto` | Async extraction (`wait=true` to block, `callback_url=` for production) |
| GET | `/extract/status/{job_id}` | Poll result |
| POST | `/extract/id/sync?doc_type=auto` | Sync extraction |
| DELETE | `/extract/job/{job_id}` | Remove job |

`doc_type`: `passport` \| `national_id` \| `drivers_license` \| `residence_permit` \| `auto` (default — tries passport, then national_id, then drivers_license, in that order). Pick `residence_permit` explicitly; its MRZ format can't be told apart from `national_id`'s.

`file_back`: optional second image (multipart field) for two-sided documents — AAMVA's PDF417 is usually on the back, the Ethiopian ID's QR is on the back and its FAN barcode is on the front. Order doesn't matter, both sides are classified by content.

---

## Usage Examples

```bash
# Auto-detect document type, wait for the full result (production: use callback_url instead)
curl -X POST "http://localhost:8000/extract/id/sync?doc_type=auto" \
  -F "file=@ethiopian_id.jpg"

# Known document type — skips the wasted passport-MRZ search, much faster
curl -X POST "http://localhost:8000/extract/id/sync?doc_type=national_id" \
  -F "file=@ethiopian_id_front.jpg" -F "file_back=@ethiopian_id_back.jpg"

# Production pattern: fire-and-forget with a webhook callback
curl -X POST "http://localhost:8000/extract/id?doc_type=drivers_license&callback_url=https://your-service/callback" \
  -F "file=@dl_front.jpg" -F "file_back=@dl_back.jpg"
```

```bash
# Python test client
python test_client.py passport.jpg passport sync
python test_client.py ethiopian_id.jpg national_id sync
python test_client.py dl_front.jpg drivers_license sync dl_back.jpg
```

---

## Response Format

`extracted_data` is a flat convenience view; `document` is the full
provenance-carrying shape — every field is `{value, raw, state,
confidence, source, source_tier, agreeing_sources}`, not a bare string.
`state` is one of `read` / `unreadable` / `printed_blank` /
`absent_from_specimen` / `not_applicable` — check `state == "read"`
before trusting `value`.

```json
{
  "job_id": "abc-123",
  "status": "completed",
  "pipeline": "idx_pipeline",
  "document_type": "national_id",
  "extraction_method": "barcode+ocr",
  "confidence": "high",
  "coverage_tier": "A",
  "human_review_required": false,
  "warnings": [],
  "extracted_data": {
    "full_name": "MESAY KEBBEDE LEMMA",
    "id_number": "5304732902634061",
    "date_of_birth": "1996-11-28",
    "gender": "M"
  },
  "document": {
    "document_category": "national_id",
    "document_number": {
      "value": "5304732902634061", "raw": "5304732902634061",
      "state": "read", "confidence": 0.9,
      "source": "barcode", "source_tier": 1, "agreeing_sources": []
    },
    "full_name": {
      "value": "Mesay Kebbede Lemma", "raw": "Mesay Kebbede Lemma",
      "state": "read", "confidence": 0.55,
      "source": "label_anchor", "source_tier": 3, "agreeing_sources": []
    },
    "verification_checks": {"dob_dual_calendar_plausible": true},
    "mrz_checks": {}, "warnings": [], "human_review_required": false
  },
  "validation": {"suspicious": false, "reasons": []},
  "total_duration_seconds": 12.3
}
```

---

## Known issues on this machine

- **Vulkan/Intel-iGPU instability**: Ollama's Vulkan backend on this
  Iris Xe iGPU intermittently crashes ("token repeat limit reached", or
  a harder `ErrorDeviceLost` under some configs). `ollama_client.py`'s
  `vision_chat()` retries once on CPU (`num_gpu=0`) when this happens —
  slower, but numerically stable. This mostly affects channels 3-4
  (Ollama calls); channels 1-2-5 never touch the GPU at all.
- **`auto` doc_type pays for a wasted MRZ search** on non-passport
  documents before reaching the right tier (e.g. ~40s TD3 search on an
  Ethiopian Digital ID, which has no MRZ, before the fast barcode tier
  runs). If you know the document type, pass it explicitly — this is
  the single biggest speed win available today.
- Local vision-model accuracy (channels 3-4) on dense, security-patterned
  documents is genuinely limited on this hardware — `validators.py`'s
  `sanity_check()` flags implausible results (institutional-keyword
  names, malformed MRZ, cross-field contradictions) but can't fix the
  underlying read. Barcode/MRZ-sourced fields (channels 1-2) don't have
  this problem — they're checksum-verified, not model guesses.

Machine: HP ZBook Firefly 15 G8 | Intel Iris Xe | 22.8GB VRAM | Vulkan
# ID-exract-with-AI-agent
